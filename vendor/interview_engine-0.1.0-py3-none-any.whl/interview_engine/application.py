"""Application service for one HTTP-driven interview session.

No console or transport concerns live here. The service advances the graph until
it reaches a typed founder-input boundary or completion.
"""
from __future__ import annotations
import json,logging,time
from contextlib import nullcontext, contextmanager
from pathlib import Path
from uuid import uuid4
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.serde.jsonplus import JsonPlusSerializer
from vmodel_contracts import AppArchetype,ConOpsDocument,IntakeSubmission,IntentModel
from vmodel_contracts.facets import COVERAGE_SCHEMA
from vmodel_contracts.interactive import InputKind,InputOption,InputRequest,InputResponse,NextStep,ProcessStatus
from vmodel_contracts.runtime import artifacts_root
from .conops_stage import founder_decision,render_conops
from .graph import build_graph
from .progress import ProgressBus,stderr_printer
from .telemetry import UsageLog,jsonl_sink
from . import session_models, model_config

_log=logging.getLogger("interview_engine.application")


def _graph_tenant_claims(pg_store,pg_claim):
    """(owner, auth-session) tenant claims for the graph's Postgres connections.

    The claims' session GUC must name a live AUTH session: delivery's forced
    RLS (20261007150000, requi_session_active()) checks
    request.jwt.claim.session_id against auth.sessions, and the store carries
    that pair - tenant_worker builds one registry per (owner, auth session).
    pg_claim.session_id is the INTERVIEW session (the lease fence identity);
    claiming with it reads every FORCE-RLS tenant table as empty, which was the
    2026-10-26 'session-row-missing' guard-lock rejection. Claimless stores
    (mirrored-DDL superuser tests) keep the legacy pair.
    """
    claims=getattr(pg_store,'claims',None)
    if claims is not None:return claims
    return (pg_claim.owner_id,pg_claim.session_id)


def durable_progress_signal(event):
    """Persist meaningful boundaries, not elapsed-time/model-call duplicates."""
    if event.status=="failed":return True
    if event.stage=="conops":
        # Console/raw-call signals still receive every field/repair event. The
        # durable journal needs one validated item update, not two transactions
        # per subfield. Keep phase and founder-decision boundaries too.
        return event.status=="item_completed" or (event.status in ("started","completed") and
            event.label in ("Building Concept of Operations","Concept of Operations decision"))
    return event.status != "heartbeat" and not event.stage.startswith("llm_call:")


class InterviewApplication:
    """Stateful graph driver. HTTP supplies typed responses; graph owns domain state."""
    def __init__(self,session_id:str,task_id:str,idea:str,*,artifact_root:str|None=None,model_route:str|None=None,pinned_models:dict|None=None,initial_model:str|None=None,pg_store=None,pg_claim=None,progress_mode:str="buffered"):
        if pg_store is None or pg_claim is None:raise ValueError('authenticated PG store and lease claim required')
        self.produced_checkpoint_id=None
        self.session_id,self.task_id=session_id,task_id
        from .session_runtime import SessionRuntime
        self.runtime=SessionRuntime(session_id=session_id)
        self.model_route=model_route
        self.model_map=pinned_models if pinned_models is not None else session_models.resolve(model_route,initial_model) if model_route else None
        if self.model_map is not None:session_models.validate(self.model_map,model_route,preflight=pinned_models is None)
        self.outdir=artifacts_root(artifact_root)/session_id/'interview'
        self.documents=None
        from .pg_documents import InterviewDocuments
        from .evidence import DatabaseEvidenceLake
        self.documents=InterviewDocuments(pg_store,pg_claim,task_id)
        self.evidence=DatabaseEvidenceLake(self.documents,task_id)
        self.schema_binding=self.evidence.bind_session(session_id)
        from .pg_checkpoint import FencedPostgresSaver, LeaseFence
        tenant_claims=_graph_tenant_claims(pg_store,pg_claim)
        from . import model_config as _mc
        self._staging=_mc.StagingContext(session_id,pg_store,pg_claim)
        _log.info("staging.ready session=%s",session_id)
        saver=FencedPostgresSaver(pg_store.pool,
            lease=LeaseFence(session_id,pg_claim.generation,pg_claim.epoch),
            serde=JsonPlusSerializer(allowed_msgpack_modules=[AppArchetype]),
            claims=tenant_claims)
        t_setup=time.monotonic();_log.info("saver.setup.begin session=%s",session_id)
        restore_row=getattr(pg_store,'_answer_checkpoint_row',None)
        if restore_row is not None and restore_row.get('thread_id')==session_id and getattr(saver,'_answer_enabled',False):
            restored=saver._load_checkpoint_tuple(restore_row)
            identity=(session_id,restore_row['checkpoint_ns'])
            saver._answer_memory={(*identity,restore_row['checkpoint_id']):restored}
            saver._answer_latest={identity:restore_row['checkpoint_id']}
            pg_store._answer_checkpoint_row=None
        prepared=getattr(pg_store,'_checkpoint_schema_version',None)
        if prepared is None or prepared<len(saver.MIGRATIONS)-1:saver.setup()
        _log.info("saver.setup.end session=%s dur_ms=%d",session_id,int((time.monotonic()-t_setup)*1000))
        log=UsageLog(session_id,sink=(lambda usage:self.documents.append('interview/usage.jsonl',(usage.model_dump_json()+'\n').encode())) if self.documents is not None else jsonl_sink(self.outdir/'usage.jsonl'))
        self.usage_log=log
        progress=ProgressBus();progress.subscribe(stderr_printer())
        from .pg_journal import BufferedJournal, ObservationalJournal
        if progress_mode not in ('buffered','observational'):
            raise ValueError('unknown progress mode')
        journal_class=ObservationalJournal if progress_mode == 'observational' else BufferedJournal
        self.progress_journal=journal_class(pg_store,pg_claim,session_id,task_id)
        self._pg_store=pg_store;self._pg_claim=pg_claim
        if not hasattr(self,'_staging'):self._staging=None
        def journal_signal(ev):
            if not durable_progress_signal(ev):return
            # The interview graph emits intent and ConOps stages through one bus.
            phase = "conops" if "conops" in ev.stage.lower() or "concept" in ev.stage.lower() else "intent"
            self.progress_journal.append(phase_key=phase,stage=ev.stage,label=ev.label,
                status=ev.status if ev.status in ("started","completed","failed","heartbeat","item_started","item_completed") else "heartbeat",detail=ev.detail,completed=ev.completed,total=ev.total)
        progress.subscribe(journal_signal)
        def heartbeat_signal(stage, label, elapsed):
            # model_config already prints transient heartbeat lines. Never open
            # a fenced database transaction just to persist an elapsed clock.
            pass
        self._heartbeat_signal=heartbeat_signal
        def call_end_signal(ev):
            # model_config logs the call; UsageLog/accounting retain paid work.
            # The journal only needs graph stage/item boundaries and failures.
            pass
        self._call_end_signal=call_end_signal
        with self._runtime_context():
            from .verification import VerificationLog
            self.graph=build_graph(log,checkpointer=saver,progress=progress,verification_log=VerificationLog(self.outdir/'verification.jsonl'),conops_enabled=True,raw_output_dir=self.outdir/'debug',
                session_id=session_id,schema_id=self.schema_binding.schema_id,schema_version=self.schema_binding.schema_version,evidence_lake=self.evidence,documents=self.documents)
        self.checkpointer=saver;self.saver=saver
        self.cfg={'configurable':{'thread_id':session_id,'checkpoint_ns':''}}
        submission=IntakeSubmission(free_text=idea,founder_id='http-founder',submission_id=session_id)
        self.state={'messages':[HumanMessage(content=idea)],'submission':submission.model_dump(mode='json')}
        self.result=None;self.open_input=None;self.finished=False

    @contextmanager
    def _runtime_context(self):
        token=model_config._session_llm_log.set(str(self.outdir/'llm-calls.jsonl'))
        # PR B staged provider responses: DB-backed sessions stage every usable
        # provider response durably before interpretation (replay, never rebill).
        staging_token=None
        # _staging is optional (None outside DB-backed sessions) and absent on
        # instances built without __init__ (isolated unit constructions).
        if getattr(self, '_staging', None) is not None:
            staging_token=model_config._response_staging.set(self._staging)
        heartbeat_token=model_config._progress_heartbeat.set(self._heartbeat_signal)
        call_end_token=model_config._progress_call_end.set(self._call_end_signal)
        from .stop_fence import _stopped_usage
        def stopped_usage(response,*,stage,provider,model):
            usage=getattr(response,'usage_metadata',None)
            if not isinstance(usage,dict):
                # Missing usage must remain explicit operator evidence, not 0.
                model_config._log_llm({'event':'stopped_usage_unknown','stage':stage,'provider':provider,'model':model})
                return
            self.usage_log.record(stage,provider,model,usage)
        usage_token=_stopped_usage.set(stopped_usage)
        try:
            from .session_runtime import use
            from .document_diagnostics import bind as bind_diagnostics
            with bind_diagnostics(getattr(self,'documents',None),self.outdir.parent),use(self.runtime), session_models.use(self.model_map) if self.model_map is not None else nullcontext():
                yield
        finally:
            if staging_token is not None:model_config._response_staging.reset(staging_token)
            _stopped_usage.reset(usage_token)
            model_config._progress_call_end.reset(call_end_token)
            model_config._progress_heartbeat.reset(heartbeat_token)
            model_config._session_llm_log.reset(token)

    def advance(self,response:InputResponse|None=None):
        from .stop_fence import check_execution
        check_execution()
        _log.info("advance.enter session=%s finished=%s response=%s",self.session_id,self.finished,'yes' if response is not None else 'no')
        rework_backup=None;rework_input=None
        if response is not None:
            if self.open_input is None or response.input_id!=self.open_input.input_id:raise ValueError('stale input')
            value=response.value
            if self.open_input.context.get('decision_purpose')=='semantic_review':
                from vmodel_contracts.semantic_review import SemanticReview
                original=SemanticReview.model_validate(self.result['semantic_review'])
                payload=json.loads(str(value))
                if payload.get('revision')!=original.revision:raise ValueError('semantic review changed')
                reviewed=SemanticReview.model_validate({**original.model_dump(),'decisions':payload.get('decisions',[])})
                if any(d.actor!=response.actor_id for d in reviewed.decisions):raise ValueError('semantic decision actor mismatch')
                resolved=reviewed.resolved_candidate(IntentModel.model_validate)
                self._update_checkpoint({'intent_model':resolved,'semantic_review':reviewed.model_dump(mode='json'),'semantic_review_resolved':True})
                self._publish_document(lambda:self._write_document('semantic-review.json',reviewed.model_dump_json(indent=2)))
                self.result={**self.result,'intent_model':resolved,'semantic_review':reviewed.model_dump(mode='json'),'semantic_review_resolved':True}
                self.open_input=None;self.state={}
            if self.open_input is not None and self.open_input.kind==InputKind.APPROVAL:
                if response.founder_inputs and value in (0,1):
                    # Founder answers to open inputs are recorded for both approval and rework.
                    from vmodel_contracts.founder_register import FounderRegister,apply_resolutions
                    register=FounderRegister.model_validate(self.result['intent_model']['founder_register'])
                    updated=apply_resolutions(register,response.founder_inputs,response.actor_id)
                    self.result['intent_model']={**self.result['intent_model'],'founder_register':updated.model_dump(mode='json')}
                    self._update_checkpoint({'intent_model':self.result['intent_model']})
                if value == 1:
                    self._finish();return None
                if value == 0:
                    # Archive before changing the checkpoint. Rework ConOps only;
                    # the reviewed intent and its source transcript remain intact.
                    archive=self.outdir/'review-history'
                    if getattr(self,'documents',None) is None:archive.mkdir(exist_ok=True)
                    from .stop_fence import guarded_publish
                    self._publish_document(lambda:self._write_document(f'review-history/{self.open_input.input_id}.json',json.dumps(
                        {'intent_model':self.result['intent_model'],'conops':self.result['conops'],
                         'guidance':response.rationale or ''},ensure_ascii=False,indent=2)))
                    rework_backup=dict(self.result);rework_input=self.open_input
                    self._update_checkpoint({'conops':None,'conops_draft':None,'conops_decision_attempts':0})
                    self.state={'messages':[HumanMessage(content=response.rationale or 'Regenerate the ConOps concepts for review.')]}
                    self.open_input=None
                elif value != 1:raise ValueError('approval response must use a declared option value')
            answer=str(value)
            if self.open_input is not None and self.open_input.rationale_required:
                if not response.rationale:raise ValueError('typed input requires a rationale')
                answer=f"{value} - {response.rationale}"
            if self.open_input is not None:self.state={'messages':[HumanMessage(content=answer)]}
        while not self.finished:
            try:
                with self._runtime_context():
                    if getattr(self, '_staging', None) is not None:
                        # Anchor for this advance: the pinned checkpoint when
                        # restored, else the session's published pointer
                        # ('bootstrap' first). The super-step half of the
                        # execution point is read from the pregel scratchpad at
                        # call time - deterministic given the anchor, and immune
                        # to the async-checkpoint commit race.
                        anchor = self.cfg['configurable'].get('checkpoint_id')
                        if anchor is None:
                            published = self._pg_store.load_published(self.session_id, self._pg_claim.owner_id)
                            anchor = published['published_checkpoint_id'] if published else None
                        self._staging.set_execution_point(anchor)
                    # 'exit' durability: the turn's checkpoints are durable
                    # when invoke returns (default 'async' commits in the
                    # background, so the step publish could run before the
                    # turn's final checkpoint landed - observed 2026-10-23 as
                    # the published pointer predating the turn's state).
                    t_invoke=time.monotonic();_log.info("advance.turn.begin session=%s",self.session_id)
                    self.result=self.graph.invoke(self.state,self.cfg,durability='exit')
                    _log.info("advance.turn.end session=%s dur_ms=%d",self.session_id,int((time.monotonic()-t_invoke)*1000))
                    # Publish provenance: record the checkpoint this advance
                    # produced (its writes are durable at 'exit'). The step
                    # publish references exactly this checkpoint - a
                    # saver-latest read at publish time could otherwise select
                    # an unpublished orphan committed by a crashed prior
                    # epoch's turn.
                    if hasattr(self.graph,'get_state'):
                        cfg_view=self.cfg.get('configurable',{}) if isinstance(self.cfg,dict) else {}
                        latest=self.graph.get_state({'configurable':{'thread_id':cfg_view.get('thread_id'),
                            'checkpoint_ns':cfg_view.get('checkpoint_ns','')}})
                        snap_cfg=(getattr(latest,'config',None) or {}).get('configurable',{}) if latest is not None else {}
                        # getattr: unit constructions (__new__, no __init__) carry no attribute.
                        self.produced_checkpoint_id=snap_cfg.get('checkpoint_id') or getattr(self,'produced_checkpoint_id',None)
                    # Continue from what this turn produced: a restored cfg is
                    # pinned to the restore anchor, and invoke resumes a pinned
                    # config from that checkpoint - so without advancing the
                    # pin, every later turn on a reclaimed host replays from
                    # the anchor (2026-10-23: conops extraction replayed per
                    # answer until the LLM call budget stopped the run). A
                    # fresh host's unpinned cfg gets the same resume-latest
                    # semantics; a failed invoke leaves the pin at the last
                    # produced checkpoint, so a retry replays only that turn.
                    if getattr(self,'produced_checkpoint_id',None) and isinstance(self.cfg,dict):
                        self.cfg.setdefault('configurable',{})['checkpoint_id']=self.produced_checkpoint_id
                    check_execution()
            except Exception:
                check_execution()  # Stop must never restore a previous actionable input.
                if rework_backup is not None:
                    # Registry restores the old approval on failure. Restore its
                    # checkpoint too, so a retry/restart cannot accept a cleared
                    # or partly regenerated ConOps under that old review ID.
                    if hasattr(self.graph,'get_state'):
                        # Checkpoint restore requires a real compiled graph; stub
                        # graphs (unit constructions) carry no checkpoints.
                        from langchain_core.messages import RemoveMessage
                        current=self.graph.get_state(self.cfg).values
                        old_ids={m.id for m in rework_backup.get('messages',[]) if getattr(m,'id',None)}
                        remove=[RemoveMessage(id=m.id) for m in current.get('messages',[])
                                if getattr(m,'id',None) and m.id not in old_ids]
                        restored_cfg=self._update_checkpoint({'conops':rework_backup.get('conops'),
                            'conops_draft':rework_backup.get('conops_draft'),
                            'conops_decision_attempts':rework_backup.get('conops_decision_attempts',0),
                            'messages':remove+rework_backup.get('messages',[])})
                        # The rollback write is this owner's produced state; the
                        # failed rework's checkpoints are unpublished orphans.
                        if isinstance(restored_cfg,dict):
                            self.produced_checkpoint_id=(restored_cfg.get('configurable') or {}).get('checkpoint_id') or getattr(self,'produced_checkpoint_id',None)
                            if getattr(self,'produced_checkpoint_id',None) and isinstance(self.cfg,dict):
                                self.cfg.setdefault('configurable',{})['checkpoint_id']=self.produced_checkpoint_id
                    self.result=rework_backup;self.open_input=rework_input
                    self.state=None
                raise
            self.state=None;self.open_input=None
            verdict=self.result.get('verdict')
            if verdict and not verdict['accepted']:
                self.finished=True;raise ValueError(verdict['decline_message'])
            if self.result.get('semantic_review') and not self.result.get('semantic_review_resolved'):
                review=self.result['semantic_review']
                self.open_input=InputRequest(input_id=uuid4(),kind=InputKind.TEXT,prompt='Review these interview findings before continuing.',
                    context={'decision_purpose':'semantic_review','evidence_version':1,'session_id':self.session_id,
                             'evidence_revision':__import__('hashlib').sha256(json.dumps({'semantic_review':review},sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest(),
                             'evidence':{'semantic_review':review}})
                _log.info("advance.return session=%s kind=review",self.session_id)
                return self.open_input
            if self.result.get('conops'):
                if not self.result['intent_model'].get('founder_register'):
                    from .completeness import inventory
                    register=inventory(self.session_id,self.result['intent_model'],self.result.get('messages',[]),self.result['conops'])
                    self.result['intent_model']={**self.result['intent_model'],'founder_register':register}
                    self._update_checkpoint({'intent_model':self.result['intent_model']})
                self.open_input=InputRequest(input_id=uuid4(),kind=InputKind.APPROVAL,prompt='Approve this intent model?',
                    options=[InputOption(value=1,label='Proceed'),InputOption(value=0,label='Edit')],
                    context=self._decision_context('interview_approval'))
                _log.info("advance.return session=%s kind=approval",self.session_id)
                return self.open_input
            last=self.result['messages'][-1].content
            if '[INTERVIEW COMPLETE]' in last:self.state={};continue
            if self.result.get('conops_draft'):
                decision=founder_decision(self._decision_context('conops_concept')['evidence']['conops_draft'])
                self.open_input=InputRequest(input_id=uuid4(),kind=InputKind.CHOICE,prompt=decision['prompt'],
                    options=[InputOption.model_validate(o) for o in decision['options']],rationale_required=decision.get('rationale_required',False),
                    context=self._decision_context('conops_concept'))
            else:self.open_input=InputRequest(input_id=uuid4(),kind=InputKind.TEXT,prompt=last)
            _log.info("advance.return session=%s kind=question",self.session_id)
            return self.open_input
        _log.info("advance.return session=%s kind=none finished=%s result_keys=%s",self.session_id,self.finished,sorted(self.result.keys()) if isinstance(self.result,dict) else type(self.result).__name__)
        return None

    def _update_checkpoint(self,values):
        """A direct state write is produced work, not an unpublished saver-latest."""
        updated=self.graph.update_state(self.cfg,values)
        checkpoint=(updated.get('configurable') or {}).get('checkpoint_id') if isinstance(updated,dict) else None
        if checkpoint:
            self.produced_checkpoint_id=checkpoint
            self.cfg.setdefault('configurable',{})['checkpoint_id']=checkpoint
        return updated

    def _decision_context(self,purpose:str)->dict:
        """Code-owned, bounded review evidence. Never infer purpose from prompts."""
        import hashlib
        if purpose=='interview_approval':
            evidence={'intent_model':IntentModel.model_validate(self.result['intent_model']).model_dump(mode='json'),
                      'conops':ConOpsDocument.model_validate(self.result['conops']).model_dump(mode='json')}
        else:
            from .conops_stage import validate_draft
            founder_turns={i for i,m in enumerate(self.result.get('messages',[])) if getattr(m,'type',None)=='human'}
            evidence={'conops_draft':validate_draft(self.result['conops_draft'],founder_turns)}
        raw=json.dumps(evidence,sort_keys=True,separators=(',',':'),ensure_ascii=False)
        if len(raw.encode('utf-8'))>1_000_000:
            raise ValueError('decision review evidence exceeds 1 MB')
        return {'decision_purpose':purpose,'evidence_version':1,'session_id':self.session_id,
                'evidence_revision':hashlib.sha256(raw.encode('utf-8')).hexdigest(),'evidence':evidence}

    def _publish_document(self,call):
        # PG writes lock and validate task + lease in their own connection.
        # An outer delivery task lock would wait on itself across two pools.
        if getattr(self,'documents',None) is not None:return call()
        from .stop_fence import guarded_publish
        return guarded_publish(call)

    def _finish(self):
        return self._publish_document(self._finish_outputs)

    def _write_document(self,name,text):
        if getattr(self,'documents',None) is not None:return self.documents.write('interview/'+name,text.encode())
        return (self.outdir/name).write_text(text)

    def _finish_outputs(self):
        intent=IntentModel.model_validate(self.result['intent_model']);conops=ConOpsDocument.model_validate(self.result['conops'])
        values={'intent_model.json':intent.model_dump_json(indent=2),'conops.json':conops.model_dump_json(indent=2),'conops.md':render_conops(conops)}
        if intent.founder_register:values['founder-decisions.json']=intent.founder_register.model_dump_json(indent=2)
        if getattr(self,'documents',None) is not None:self.documents.write_many({'interview/'+name:text.encode() for name,text in values.items()})
        else:
            for name,text in values.items():self._write_document(name,text)
        self.finished=True;self.open_input=None
