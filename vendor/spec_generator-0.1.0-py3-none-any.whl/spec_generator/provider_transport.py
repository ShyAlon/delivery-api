"""Uninstalled SDK wire-boundary prototype. Inner transport must be supplied.

No HTTP client, credential, endpoint, rate or bound is created here. A runner
must bind a durable-job gateway and reviewed serialized-request resolver first.
Synchronous JSON and terminal-usage SSE supported; async wire prototypes exist; no runner installs them.
"""
import base64
import hashlib
import json
import sys
import uuid
import httpx
import random
import time
from datetime import datetime, timezone
from .attempt_admission import AdmissionUnavailable, AdmissionRefused

# Bounded retry of the RESERVE step only. A refused reserve leaves no attempt row, nothing is sent to the
# provider and nothing is billed, and the retry reuses the same attempt id (the ledger replays an existing
# attempt with the same fingerprint instead of creating a second one). Never retried: a refusal the server
# names as deterministic (AdmissionDenied / TenantAccessDenied), a socket timeout or broken frame (the
# channel may be out of step), start, settle, and anything after the request went out.
RESERVE_TRIES=3
RESERVE_WAITS=(2.0,5.0)
_DETERMINISTIC=('AdmissionDenied','TenantAccessDenied')
_sleep=time.sleep
_asleep=None


def _retryable(exc):
    return isinstance(exc,AdmissionRefused) and not exc.reason.startswith(_DETERMINISTIC)


def _note_retry(exc,try_no,t0,wait):
    try:
        from . import model_config
        msg=(f"  WARNING boundary=admission-retry {datetime.now(timezone.utc).isoformat(timespec='seconds')} "
             f"elapsed={time.monotonic()-t0:.1f}s try={try_no}/{RESERVE_TRIES} error={type(exc).__name__}: {str(exc)[:300]} "
             f"decision={'retry-in-%.1fs' % wait if wait is not None else 'stop'} billing=no-attempt-created")
        model_config._console_line(msg)
        model_config._log_llm({'event':'admission_retry','try':try_no,'tries':RESERVE_TRIES,'error':{'class':type(exc).__name__,'message':str(exc)[:300]},
                               'decision':'retry' if wait is not None else 'stop'})
    except Exception:pass


def _reserve_serialized_with_retry(gateway,**kw):
    t0=time.monotonic()
    for try_no in range(1,RESERVE_TRIES+1):
        try:return gateway.reserve_serialized(**kw)
        except AdmissionUnavailable as exc:
            wait=RESERVE_WAITS[try_no-1]+random.uniform(0,0.5) if _retryable(exc) and try_no<RESERVE_TRIES else None
            _note_retry(exc,try_no,t0,wait)
            if wait is None:raise
            from .stop_fence import check_execution
            check_execution();_sleep(wait);check_execution()


async def _areserve_serialized_with_retry(gateway,**kw):
    import asyncio
    t0=time.monotonic()
    for try_no in range(1,RESERVE_TRIES+1):
        try:return gateway.reserve_serialized(**kw)
        except AdmissionUnavailable as exc:
            wait=RESERVE_WAITS[try_no-1]+random.uniform(0,0.5) if _retryable(exc) and try_no<RESERVE_TRIES else None
            _note_retry(exc,try_no,t0,wait)
            if wait is None:raise
            from .stop_fence import check_execution
            check_execution();await (_asleep or asyncio.sleep)(wait);check_execution()


CONNECT_TRIES=3
_CONNECT_ERRORS=(httpx.ConnectError,httpx.ConnectTimeout)


class _Released(Exception):
    """The ledger released the attempt: the provider provably never got the request."""
    def __init__(self,exc):self.exc=exc


def _release_connect_failure(gateway,attempt,exc):
    """Ask the ledger to release an attempt that never reached the provider. False keeps the uncertain path."""
    release=getattr(gateway,'release',None)
    if release is None or not isinstance(exc,_CONNECT_ERRORS):return False
    try:
        release(attempt,{'kind':'connect-failure','error_class':type(exc).__name__,'bytes_sent':0,'response_seen':False})
        return True
    except Exception as refused:
        _note_connect(exc,1,None,None,f'release-refused: {type(refused).__name__}: {(getattr(refused,"reason","") or str(refused))[:200]}')
        return False


def _note_connect(exc,try_no,t0,wait,released='yes'):
    try:
        from . import model_config
        elapsed=(time.monotonic()-t0) if t0 is not None else 0.0
        msg=(f"  WARNING boundary=provider-connect {datetime.now(timezone.utc).isoformat(timespec='seconds')} "
             f"elapsed={elapsed:.1f}s try={try_no}/{CONNECT_TRIES} error={type(exc).__name__}: {str(exc)[:300]} "
             f"released={released} decision={'retry-in-%.1fs' % wait if wait is not None else 'stop'} billing=none-for-released-attempt")
        model_config._console_line(msg)
        model_config._log_llm({'event':'provider_connect_retry','try':try_no,'tries':CONNECT_TRIES,'error':{'class':type(exc).__name__,'message':str(exc)[:300]},
                               'released':released,'decision':'retry' if wait is not None else 'stop'})
    except Exception:pass


class WireEvidence:
    """Bounded metadata + exact raw terminal usage; never keys/request bodies."""
    def __init__(self,gateway,attempt):
        self.gateway=gateway;self.attempt=attempt;self.sha=hashlib.sha256();self.bytes=0
        self.cr=0;self.lf=0;self.events=0;self.usage=None;self.done=False;self.reported=False
    def chunk(self,chunk):
        self.sha.update(chunk);self.bytes+=len(chunk);self.cr+=chunk.count(b'\r');self.lf+=chunk.count(b'\n')
    def emit(self,status,error=None):
        if self.reported:return
        self.reported=True
        callback=getattr(self.gateway,'record_wire_evidence',None)
        if callback is not None:
            # Persistence failure is visible, not permission to drop evidence.
            callback(self.attempt,{'status':status,'response_sha256':self.sha.hexdigest(),
                'response_bytes':self.bytes,'cr_count':self.cr,'lf_count':self.lf,
                'event_count':self.events,'terminal_usage':self.usage,'done_seen':self.done,
                'error_class':type(error).__name__ if error is not None else None})


class SSELines:
    """Bounded incremental LF/CRLF/CR decoder, including split CRLF."""
    def __init__(self):self.buffer=bytearray();self.skip_lf=False
    def feed(self,chunk):
        for value in chunk:
            if self.skip_lf:
                self.skip_lf=False
                if value==10:continue
            if value in (10,13):
                line=bytes(self.buffer);self.buffer.clear();self.skip_lf=value==13
                yield line
            else:
                self.buffer.append(value)
                if len(self.buffer)>65536:raise AdmissionUnavailable('oversized provider SSE line')


def _terminal_usage_choices(choices):
    # OpenAI's separate empty-choice usage event and DeepSeek's documented
    # finish-only choice event are both terminal, never a content-bearing event.
    if choices==[]:return True
    if not isinstance(choices,list) or not choices:return False
    for choice in choices:
        if not isinstance(choice,dict) or choice.get('finish_reason') not in ('stop','length','tool_calls','content_filter','insufficient_system_resource'):return False
        delta=choice.get('delta')
        if not isinstance(delta,dict) or any(value not in (None,'',[],{}) for value in delta.values()):return False
    return True


class AdmittedTransport(httpx.BaseTransport):
    def __init__(self, inner, gateway, *, stage, provider, model):
        self.inner=inner;self.gateway=gateway
        self.stage=stage;self.provider=provider;self.model=model

    def handle_request(self, request):
        from .stop_fence import check_execution
        check_execution()
        # This is the final SDK payload, not a reconstruction from messages.
        if request.method!='POST' or not request.url.path.endswith('/chat/completions'):
            raise AdmissionUnavailable('unsupported SDK operation')
        raw=request.read()
        try:
            payload=json.loads(raw)
            if not isinstance(payload,dict) or payload.get('model')!=self.model:
                raise ValueError('model mismatch')
            if type(payload.get('stream',False)) is not bool:
                raise ValueError('boolean stream flag required')
            if payload.get('stream') and (not isinstance(payload.get('stream_options'),dict) or payload['stream_options'].get('include_usage') is not True):
                raise ValueError('terminal streaming usage required')
            caps=[payload[k] for k in ('max_tokens','max_completion_tokens') if k in payload]
            if len(caps)!=1 or type(caps[0]) is not int or caps[0]<=0:
                raise ValueError('one explicit output cap required')
        except (ValueError,TypeError) as exc:
            raise AdmissionUnavailable('unsupported complete SDK request') from exc
        t0=time.monotonic()
        for try_no in range(1,CONNECT_TRIES+1):
            try:return self._dispatch(request,raw,payload,caps)
            except _Released as rel:
                wait=RESERVE_WAITS[try_no-1]+random.uniform(0,0.5) if try_no<CONNECT_TRIES else None
                _note_connect(rel.exc,try_no,t0,wait)
                if wait is None:raise rel.exc
                check_execution();_sleep(wait);check_execution()

    def _dispatch(self,request,raw,payload,caps):
        from .stop_fence import check_execution
        attempt=_reserve_serialized_with_retry(self.gateway,attempt_id=uuid.uuid4().hex,
            stage=self.stage,provider=self.provider,model=self.model,
            serialized_request=base64.b64encode(raw).decode('ascii'),max_output_tokens=caps[0])
        if not attempt:raise AdmissionUnavailable('serialized request was not admitted')
        self.gateway.start(attempt)
        response=None;settled=False
        try:
            # Headers and URL stay in the SDK transport, never in the ledger.
            response=self.inner.handle_request(request)
            if response.status_code<200 or response.status_code>=300:
                raise AdmissionUnavailable(f'provider HTTP {response.status_code} response cannot prove usage')
            if payload.get('stream'):
                if 'text/event-stream' not in response.headers.get('content-type',''):
                    raise AdmissionUnavailable('unexpected streaming content type')
                return httpx.Response(response.status_code,headers={k:v for k,v in response.headers.items() if k.lower() not in ('content-encoding','content-length')},
                    stream=UsageStream(response,self.gateway,attempt))
            body=response.read()
            envelope=json.loads(body)
            if not isinstance(envelope,dict) or not isinstance(envelope.get('usage'),dict):
                raise AdmissionUnavailable('raw provider usage unavailable')
            self.gateway.settle_raw(attempt,envelope['usage'])
            settled=True
            check_execution()
            return response
        except BaseException:
            if response is not None:response.close()
            if not settled:
                exc=sys.exc_info()[1]
                if response is None and _release_connect_failure(self.gateway,attempt,exc):raise _Released(exc) from exc
                try:self.gateway.uncertain(attempt)
                except Exception as error:
                    from .attempt_admission import _uncertainty_write_failed
                    _uncertainty_write_failed(error)
            raise

    def close(self):self.inner.close()


class RawEvidenceStream(httpx.SyncByteStream):
    """Hash observed wire bytes before HTTP content decoding."""
    def __init__(self,stream,evidence):self.stream,self.evidence=stream,evidence
    def __iter__(self):
        for chunk in self.stream:
            self.evidence.chunk(chunk)
            yield chunk
    def close(self):self.stream.close()

class AsyncRawEvidenceStream(httpx.AsyncByteStream):
    """Hash observed wire bytes before HTTP content decoding."""
    def __init__(self,stream,evidence):self.stream,self.evidence=stream,evidence
    async def __aiter__(self):
        async for chunk in self.stream:
            self.evidence.chunk(chunk)
            yield chunk
    async def aclose(self):await self.stream.aclose()

class UsageStream(httpx.SyncByteStream):
    """Pass decoded bytes through; settle terminal usage before SDK DONE close.

    Early close, broken/malformed/oversized SSE or missing usage keeps uncertainty.
    """
    def __init__(self,response,gateway,attempt):
        self.response=response;self.gateway=gateway;self.attempt=attempt
        self.finished=False;self.marked=False;self.evidence=WireEvidence(gateway,attempt)
        self.response.stream=RawEvidenceStream(self.response.stream,self.evidence)

    def uncertain(self):
        if self.finished or self.marked:return
        self.marked=True
        try:self.gateway.uncertain(self.attempt)
        except Exception as error:
            from .attempt_admission import _uncertainty_write_failed
            _uncertainty_write_failed(error)

    def __iter__(self):
        lines=SSELines();data=[];size=0;usage=None;done=False
        try:
            for chunk in self.response.iter_bytes():
                for line in lines.feed(chunk):
                    size+=len(line)
                    if size>65536:raise AdmissionUnavailable('oversized provider SSE event')
                    if line.startswith(b'data:'):
                        data.append(line[5:].lstrip(b' '))
                    elif not line:
                        if data:
                            value=b'\n'.join(data);data=[];self.evidence.events+=1
                            if done:raise AdmissionUnavailable('provider event after DONE')
                            if value==b'[DONE]':
                                self.evidence.done=True
                                if usage is None:raise AdmissionUnavailable('DONE without terminal usage')
                                self.gateway.settle_raw(self.attempt,usage)
                                self.finished=True;done=True
                                from .stop_fence import check_execution
                                check_execution()
                            else:
                                event=json.loads(value)
                                if not isinstance(event,dict):raise AdmissionUnavailable('invalid provider SSE event')
                                if event.get('usage') is not None:
                                    if not isinstance(event['usage'],dict) or usage is not None:
                                        raise AdmissionUnavailable('ambiguous provider terminal usage')
                                    if not _terminal_usage_choices(event.get('choices')):raise AdmissionUnavailable('usage is not terminal')
                                    usage=event['usage'];self.evidence.usage=usage
                                elif usage is not None:raise AdmissionUnavailable('content after terminal usage')
                        size=0
                yield chunk
            if lines.buffer.strip() or data or not done or usage is None:
                raise AdmissionUnavailable('incomplete terminal provider usage')
        except BaseException as exc:
            self.evidence.emit('failed',exc)
            raise
        finally:
            try:self.evidence.emit('settled' if self.finished else 'closed_without_settlement')
            finally:
                try:self.uncertain()
                finally:self.response.close()

    def close(self):
        try:self.evidence.emit('settled' if self.finished else 'early_close')
        finally:
            try:self.uncertain()
            finally:self.response.close()


class AsyncAdmittedTransport(httpx.AsyncBaseTransport):
    def __init__(self, inner, gateway, *, stage, provider, model):
        self.inner=inner;self.gateway=gateway
        self.stage=stage;self.provider=provider;self.model=model

    async def handle_async_request(self, request):
        from .stop_fence import check_execution
        check_execution()
        # This is the final SDK payload, not a reconstruction from messages.
        if request.method!='POST' or not request.url.path.endswith('/chat/completions'):
            raise AdmissionUnavailable('unsupported SDK operation')
        raw=await request.aread()
        try:
            payload=json.loads(raw)
            if not isinstance(payload,dict) or payload.get('model')!=self.model:
                raise ValueError('model mismatch')
            if type(payload.get('stream',False)) is not bool:
                raise ValueError('boolean stream flag required')
            if payload.get('stream') and (not isinstance(payload.get('stream_options'),dict) or payload['stream_options'].get('include_usage') is not True):
                raise ValueError('terminal streaming usage required')
            caps=[payload[k] for k in ('max_tokens','max_completion_tokens') if k in payload]
            if len(caps)!=1 or type(caps[0]) is not int or caps[0]<=0:
                raise ValueError('one explicit output cap required')
        except (ValueError,TypeError) as exc:
            raise AdmissionUnavailable('unsupported complete SDK request') from exc
        import asyncio
        t0=time.monotonic()
        for try_no in range(1,CONNECT_TRIES+1):
            try:return await self._adispatch(request,raw,payload,caps)
            except _Released as rel:
                wait=RESERVE_WAITS[try_no-1]+random.uniform(0,0.5) if try_no<CONNECT_TRIES else None
                _note_connect(rel.exc,try_no,t0,wait)
                if wait is None:raise rel.exc
                check_execution();await (_asleep or asyncio.sleep)(wait);check_execution()

    async def _adispatch(self,request,raw,payload,caps):
        from .stop_fence import check_execution
        attempt=await _areserve_serialized_with_retry(self.gateway,attempt_id=uuid.uuid4().hex,
            stage=self.stage,provider=self.provider,model=self.model,
            serialized_request=base64.b64encode(raw).decode('ascii'),max_output_tokens=caps[0])
        if not attempt:raise AdmissionUnavailable('serialized request was not admitted')
        self.gateway.start(attempt)
        response=None;settled=False
        try:
            # Headers and URL stay in the SDK transport, never in the ledger.
            response=await self.inner.handle_async_request(request)
            if response.status_code<200 or response.status_code>=300:
                raise AdmissionUnavailable(f'provider HTTP {response.status_code} response cannot prove usage')
            if payload.get('stream'):
                if 'text/event-stream' not in response.headers.get('content-type',''):
                    raise AdmissionUnavailable('unexpected streaming content type')
                return httpx.Response(response.status_code,headers={k:v for k,v in response.headers.items() if k.lower() not in ('content-encoding','content-length')},
                    stream=AsyncUsageStream(response,self.gateway,attempt))
            body=await response.aread()
            envelope=json.loads(body)
            if not isinstance(envelope,dict) or not isinstance(envelope.get('usage'),dict):
                raise AdmissionUnavailable('raw provider usage unavailable')
            self.gateway.settle_raw(attempt,envelope['usage'])
            settled=True
            check_execution()
            return response
        except BaseException:
            if response is not None:await response.aclose()
            if not settled:
                exc=sys.exc_info()[1]
                if response is None and _release_connect_failure(self.gateway,attempt,exc):raise _Released(exc) from exc
                try:self.gateway.uncertain(attempt)
                except Exception as error:
                    from .attempt_admission import _uncertainty_write_failed
                    _uncertainty_write_failed(error)
            raise

    async def aclose(self):await self.inner.aclose()


class AsyncUsageStream(httpx.AsyncByteStream):
    """Pass decoded bytes through; settle terminal usage before SDK DONE close.

    Early close, broken/malformed/oversized SSE or missing usage keeps uncertainty.
    """
    def __init__(self,response,gateway,attempt):
        self.response=response;self.gateway=gateway;self.attempt=attempt
        self.finished=False;self.marked=False;self.evidence=WireEvidence(gateway,attempt)
        self.response.stream=AsyncRawEvidenceStream(self.response.stream,self.evidence)

    def uncertain(self):
        if self.finished or self.marked:return
        self.marked=True
        try:self.gateway.uncertain(self.attempt)
        except Exception as error:
            from .attempt_admission import _uncertainty_write_failed
            _uncertainty_write_failed(error)

    async def __aiter__(self):
        # The async SDK may ask for the same iterator again while closing DONE.
        # Terminal settlement is final; do not reopen the consumed response.
        if self.finished:return
        lines=SSELines();data=[];size=0;usage=None;done=False
        try:
            async for chunk in self.response.aiter_bytes():
                for line in lines.feed(chunk):
                    size+=len(line)
                    if size>65536:raise AdmissionUnavailable('oversized provider SSE event')
                    if line.startswith(b'data:'):
                        data.append(line[5:].lstrip(b' '))
                    elif not line:
                        if data:
                            value=b'\n'.join(data);data=[];self.evidence.events+=1
                            if done:raise AdmissionUnavailable('provider event after DONE')
                            if value==b'[DONE]':
                                self.evidence.done=True
                                if usage is None:raise AdmissionUnavailable('DONE without terminal usage')
                                self.gateway.settle_raw(self.attempt,usage)
                                self.finished=True;done=True
                                from .stop_fence import check_execution
                                check_execution()
                            else:
                                event=json.loads(value)
                                if not isinstance(event,dict):raise AdmissionUnavailable('invalid provider SSE event')
                                if event.get('usage') is not None:
                                    if not isinstance(event['usage'],dict) or usage is not None:
                                        raise AdmissionUnavailable('ambiguous provider terminal usage')
                                    if not _terminal_usage_choices(event.get('choices')):raise AdmissionUnavailable('usage is not terminal')
                                    usage=event['usage'];self.evidence.usage=usage
                                elif usage is not None:raise AdmissionUnavailable('content after terminal usage')
                        size=0
                yield chunk
            if lines.buffer.strip() or data or not done or usage is None:
                raise AdmissionUnavailable('incomplete terminal provider usage')
        except BaseException as exc:
            self.evidence.emit('failed',exc)
            raise
        finally:
            try:self.evidence.emit('settled' if self.finished else 'closed_without_settlement')
            finally:
                try:self.uncertain()
                finally:await self.response.aclose()

    async def aclose(self):
        try:self.evidence.emit('settled' if self.finished else 'early_close')
        finally:
            try:self.uncertain()
            finally:await self.response.aclose()
